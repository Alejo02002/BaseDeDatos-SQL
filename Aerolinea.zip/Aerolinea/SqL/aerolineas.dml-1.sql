-- Aviones
INSERT INTO `aerolinea`.`aviones` (`modelo`, `fabricante`, `capacidad`, `angar`) VALUES ('A120', 'Toyota', '400', '4');
INSERT INTO `aerolinea`.`aviones` (`modelo`, `fabricante`, `capacidad`, `angar`) VALUES ('B500', 'Samsung', '400', '5');
INSERT INTO `aerolinea`.`aviones` (`nro`, `modelo`, `fabricante`, `capacidad`, `angar`) VALUES ('3', 'M70', 'honda', '800', '8');
INSERT INTO `aerolinea`.`aviones` (`nro`, `modelo`, `fabricante`, `capacidad`, `angar`) VALUES ('4', 'M80', 'suzuki', '600', '6');


-- Vuelos
INSERT INTO `aerolinea`.`vuelos` (`fecha`, `hora_salida`,`hora_llegada`, `ciudad`, `nro_avion`) VALUES ('2022-10-25', '15:00','18:00','Bogota', '1');
INSERT INTO `aerolinea`.`vuelos` (`fecha`, `hora_salida`,`hora_llegada`, `ciudad`, `nro_avion`) VALUES ('2022-10-25', '18:00','22:00','Madrid', '3');
INSERT INTO `aerolinea`.`vuelos` (`fecha`, `hora_salida`,`hora_llegada`, `ciudad`, `nro_avion`) VALUES ('20221025', '07:00','11:00','Mexico', '2');
INSERT INTO `aerolinea`.`vuelos` (`fecha`, `hora_salida`,`hora_llegada`, `ciudad`, `nro_avion`) VALUES ('2022-10-30', '10:00', '12:00','Peru', '4');
INSERT INTO `aerolinea`.`vuelos` (`fecha`, `hora_salida`,`hora_llegada`, `ciudad`, `nro_avion`) VALUES ('2022-11-05', '12:00','14:00','Colombia', '4');


-- Pasajeros
INSERT INTO `aerolinea`.`pasajeros` (`pasaporte`, `nro_vuelo`) VALUES ('57845632', '1');
INSERT INTO `aerolinea`.`pasajeros` (`pasaporte`, `nro_vuelo`) VALUES ('48796542', '1');
INSERT INTO `aerolinea`.`pasajeros` (`pasaporte`, `nro_vuelo`) VALUES ('45796542', '2');
INSERT INTO `aerolinea`.`pasajeros` (`pasaporte`, `nro_vuelo`) VALUES ('38476542', '2');


-- Personal
INSERT INTO `aerolinea`.`personales` (`dni`, `nombre`, `apellido`, `area_asignada`, `nro_vuelo`) VALUES ('38457698', 'Juan', 'Gutierrez', 'mantenimiento', '1');
INSERT INTO `aerolinea`.`personales` (`dni`, `nombre`, `apellido`, `area_asignada`, `nro_vuelo`) VALUES ('42857965', 'Adrian', 'Perez', 'Piloto', '2');
INSERT INTO `aerolinea`.`personales` (`dni`, `nombre`, `apellido`, `area_asignada`, `nro_vuelo`) VALUES ('39845785', 'Pedro', 'Garcia', 'Piloto', '4');