-- Traeme el horario de salida a la ciudad "Bogota" y la capacidad del avion que abordaré
select vuelos.hora_salida, vuelos.ciudad, aviones.capacidad from vuelos 
join aviones on vuelos.nro_avion = aviones.nro where vuelos.ciudad like "bogota";

/* 
Los pilotos del personal quieren saber la hora de salida y el tipo de avion que pilotea
*/
select personales.nombre, vuelos.hora_salida, aviones.modelo from personales
join vuelos on personales.nro_vuelo = vuelos.nro
join aviones on vuelos.nro_avion = aviones.nro group by personales.area_asignada
having personales.area_asignada like "piloto";

-- Traeme los pasajeros con destino a "Madrid"
select pasajeros.pasaporte, vuelos.ciudad from pasajeros 
join vuelos on pasajeros.nro_vuelo = vuelos.nro
where vuelos.ciudad like "madrid";

-- Traeme la cantidad de pasajeros del avion de fabricante "toyota"


-- Traeme el angar del avion del piloto "adrian"
select aviones.angar, personales.nombre from aviones 
join vuelos on aviones.nro = vuelos.nro_avion
join personales on vuelos.nro = personales.nro_vuelo where personales.nombre like "adrian";